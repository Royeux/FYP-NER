import sys
import nltk
import pycrfsuite
from sklearn.model_selection import train_test_split

def extractor(file):
    """Get tokens and labels from annotated file"""
    sents = []
    with open(file, 'r') as f:
        lines = f.readlines()
        sent = []
        for line in lines:
            line = line.strip()
            if len(line) == 0:
                sents.append(sent)
                sent = []
            else:
                word, label = line.split(" ")
                sent.append((word, label))
    return sents

def tagger(sents):
    """Add POS tags to data"""
    data = []
    for i, sent in enumerate(sents):
        tokens = [t for t, label in sent]
        tagged = nltk.pos_tag(tokens)
        data.append([(w, pos, label) for (w, label), (word, pos) in zip(sent, tagged)])
    return data

def word2features(sent, i):
    """Define word features."""
    word = sent[i][0]
    postag = sent[i][1]
    features = {
        'bias': 1.0,
        'word.lower()': word.lower(),
        'word[-3:]': word[-3:],
        'word[-2:]': word[-2:],
        'word.isupper()': word.isupper(),
        'word.istitle()': word.istitle(),
        'word.isdigit()': word.isdigit(),
        'postag': postag,
        'postag[:2]': postag[:2],
    }
    if i > 0:
        word1 = sent[i-1][0]
        postag1 = sent[i-1][1]
        features.update({
            '-1:word.lower()': word1.lower(),
            '-1:word.istitle()': word1.istitle(),
            '-1:word.isupper()': word1.isupper(),
            '-1:word.isdigit()': word1.isdigit(),
            '-1:postag': postag1,
            '-1:postag[:2]': postag1[:2],
        })
    if i > 1:
        word1 = sent[i-1][0]
        postag1 = sent[i-1][1]
        word2 = sent[i-2][0]
        postag2 = sent[i-2][1]
        features.update({
            '-1:word.lower()': word1.lower(),
            '-1:word.istitle()': word1.istitle(),
            '-1:word.isupper()': word1.isupper(),
            '-1:word.isdigit()': word1.isdigit(),
            '-1:postag': postag1,
            '-1:postag[:2]': postag1[:2],
            '-2:word.lower()': word2.lower(),
            '-2:word.istitle()': word2.istitle(),
            '-2:word.isupper()': word2.isupper(),
            '-2:postag': postag2,
            '-2:postag[:2]': postag2[:2],
        })
    else:
        features['BOS'] = True
    if i < len(sent)-1:
        word1 = sent[i+1][0]
        postag1 = sent[i+1][1]
        features.update({
            '+1:word.lower()': word1.lower(),
            '+1:word.istitle()': word1.istitle(),
            '+1:word.isupper()': word1.isupper(),
            '+1:postag': postag1,
            '+1:postag[:2]': postag1[:2],
        })
    if i < len(sent)-2:
        word1 = sent[i+1][0]
        postag1 = sent[i+1][1]
        word2 = sent[i+2][0]
        postag2 = sent[i+2][1]
        features.update({
            '+1:word.lower()': word1.lower(),
            '+1:word.istitle()': word1.istitle(),
            '+1:word.isupper()': word1.isupper(),
            '+1:postag': postag1,
            '+1:postag[:2]': postag1[:2],
            '+2:word.lower()': word2.lower(),
            '+2:word.istitle()': word2.istitle(),
            '+2:word.isupper()': word2.isupper(),
            '+2:postag': postag2,
            '+2:postag[:2]': postag2[:2],
        })
    else:
        features['EOS'] = True
    return features

def extract_features(sent):
    """Extract features for every word in a sentence"""
    return [word2features(sent, i) for i in range(len(sent))]

def get_labels(sent):
    """Get the list of labels for a sentence"""
    return [label for (token, pos, label) in sent]

def decode_labels(X, y):
    """Construct dish names from tagged sequences"""
    dishes = []
    size = len(X_test)
    for i in range(size):
        dish = ""
        for x, y in zip([x['word.lower()'] for x in X[i]], y[i]):
            if y == 'B':
                dish = x + " "
            elif y == 'I':
                dish = dish + x + " "
            else:
                if dish != "":
                    dish = dish.strip()
                    dishes.append(dish)
                    dish = ""
        if dish != "":
            dish = dish.strip()
            dishes.append(dish)
            dish = ""
    return dishes

def metrics(true, pred):
    """Custom definition of metrics for precision, recall, and F1"""
    trueSet = set(true)
    predSet = set(pred)

    tp_set = predSet.intersection(trueSet)
    fp_set = predSet.difference(trueSet)
    fn_set = trueSet.difference(predSet)

    tp = len(tp_set)
    fp = len(fp_set)
    fn = len(fn_set)

    if tp == 0:
        precision = 0.0
        recall = 0.0
        f1 = 0.0
    else:
        precision = float(tp) / (tp + fp)
        recall = float(tp) / (tp + fn)
        f1 = 2.0 * precision * recall / (precision + recall)

    return precision, recall, f1


if __name__ == "__main__":

    algo = sys.argv[1] # type of algorithm to use in CRF {lbfgs,l2sgd,ap,pa,arow}       

    annot1 = "../../../data/annotated/tokens/cherry_garden_tokens.txt"
    annot2 = "../../../data/annotated/tokens/red_star_restaurant_reviews_tokens.txt"
    annot3 = "../../../data/annotated/tokens/swee_choon_tim_sum_restaurant_tokens.txt"
    annot4 = "../../../data/annotated/tokens/tim_ho_wan_plaza_singapura_tokens.txt"
    annot5 = "../../../data/annotated/tokens/victors_kitchen_sunshine_plaza_tokens.txt"

    sents1 = extractor(annot1)
    sents2 = extractor(annot2)
    sents3 = extractor(annot3)
    sents4 = extractor(annot4)
    sents5 = extractor(annot5)

    data1 = tagger(sents1)
    data2 = tagger(sents2)
    data3 = tagger(sents3)
    data4 = tagger(sents4)
    data5 = tagger(sents5)

    # Concatenate all data
    data = data1 + data2 + data3 + data4 + data5

    X = [extract_features(sent) for sent in data]
    y = [get_labels(sent) for sent in data]

    # Generate training and test set
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

    # Initiate CRF model and set parameters
    trainer = pycrfsuite.Trainer(algorithm=algo, verbose=True)
    trainer.set_params({
        #'c1': 0.1, # coefficient for L1 penalty
        'c2': 0.01, # coefficient for L2 penalty
        'max_iterations': 85, # maximum number of iterations
        'feature.possible_transitions': True # include possible but not observed transitions
    })

    # Attach training data to model
    for x, y in zip(X_train, y_train):
        trainer.append(x, y)

    # Train model
    trainer.train('crf.model')

    # Predict tags
    tagger = pycrfsuite.Tagger()
    tagger.open('crf.model')
    y_pred = [tagger.tag(x) for x in X_test]

    # Get list of dish names
    #true_dishes = decode_labels(X_test, y_test)
    #pred_dishes = decode_labels(X_test, y_pred)


    true_dishes = []
    pred_dishes = []
    size = len(X_test)
    for i in range(size):
        dish = ""
        for x, y in zip([x['word.lower()'] for x in X_test[i]], y_test[i]):
            if y == 'B':
                dish = x + " "
            elif y == 'I':
                dish = dish + x + " "
            else:
                if dish != "":
                    dish = dish.strip()
                    true_dishes.append(dish)
                    dish = ""
        if dish != "":
            dish = dish.strip()
            true_dishes.append(dish)
            dish = ""
    for i in range(size):
        dish = ""
        for x, y in zip([x['word.lower()'] for x in X_test[i]], y_pred[i]):
            if y == 'B':
                dish = x + " "
            elif y == 'I':
                dish = dish + x + " "
            else:
                if dish != "":
                    dish = dish.strip()
                    pred_dishes.append(dish)
                    dish = ""
        if dish != "":
            dish = dish.strip()
            pred_dishes.append(dish)
            dish = ""

    # Print out metrics 
    precision, recall, f1 = metrics(true_dishes, pred_dishes)
    print "Precision = {:.4f} \nRecall = {:.4f} \nF1 = {:.4f}".format(precision, recall, f1)

    predictions = list(set(pred_dishes))

    with open('results/predictions.txt', 'w') as f:
        for pred in predictions:
            f.write(pred + "\n")

    #print "True dishes: "
    #print set(true_dishes)

    #print "Predicted dishes: "
    #print set(pred_dishes)