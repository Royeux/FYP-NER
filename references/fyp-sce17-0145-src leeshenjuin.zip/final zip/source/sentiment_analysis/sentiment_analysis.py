import sys
import pickle
import xml.etree.ElementTree as ET
from operator import itemgetter
from nltk.tokenize import TweetTokenizer
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from collections import defaultdict


def vader(analyzer, sentence):
    polarity = analyzer.polarity_scores(sentence)
    if polarity['compound'] < 0:
        return "negative"
    elif polarity['neu'] == 1.0:
        return "neutral"
    elif polarity['pos'] > polarity['neg']:
        return "positive"
    else:
        return "negative"

def contextor(tokenizer, sentence, entity, start, end, dist=10):
    tokens = tokenizer.tokenize(sentence)
    mid = start + (end - start) / 2
    i = max(mid - dist, 0)
    j = min(mid + dist, len(tokens))
    context = " ".join([token for token in tokens[i:j]])
    return context

def metrics(polaritiesTrue, polaritiesPred):
    confusionMatrix = defaultdict(lambda:defaultdict(lambda:0))
    count = 0

    for polarityTrue, polarityPred in zip(polaritiesTrue, polaritiesPred):
        for (entityTrue, sentimentTrue), (entityPred, sentimentPred) in zip(polarityTrue, polarityPred):
            confusionMatrix[sentimentTrue][sentimentPred] += 1
            count += 1

    print confusionMatrix

    polarityLabels = ["positive", "negative", "neutral"]
    accuracy = sum(confusionMatrix[polarity][polarity] for polarity in polarityLabels) / float(count)

    precision = {polarity: float(confusionMatrix[polarity][polarity]) / sum([confusionMatrix[polarity][polarityOther] for polarityOther in polarityLabels]) for polarity in polarityLabels}
    recall = {polarity: float(confusionMatrix[polarity][polarity]) / sum([confusionMatrix[polarityOther][polarity] for polarityOther in polarityLabels]) for polarity in polarityLabels}
    f1 = {polarity: (2.0 * precision[polarity] * recall[polarity] / (precision[polarity] + recall[polarity])) for polarity in polarityLabels}

    print "Accuracy:"
    print accuracy

    print "Precision:"
    print precision

    print "Recall:"
    print recall

    print "F1-score:"
    print f1


def popularity(polaritiesPred):
    dishesPolarity = {}
    dishesPopularity = []

    for polarities in polaritiesPred:
        for dish, polarity in polarities:
            dish = dish.lower()
            if dish in dishesPolarity:
                if polarity in dishesPolarity[dish]:
                    dishesPolarity[dish][polarity] += 1
                else:
                    dishesPolarity[dish][polarity] = 1
            else:
                dishesPolarity[dish] = {}
                dishesPolarity[dish][polarity] = 1

    for dish, polarities in dishesPolarity.items():
        if "positive" in polarities:
            pos = polarities["positive"]
        else:
            pos = 0
        if "negative" in polarities:
            neg = polarities["negative"]
        else:
            neg = 0
        if "neutral" in polarities:
            neu = polarities["neutral"]
        else:
            neu = 0

        total = pos + neg + neu
        pos = "{:.4f}".format(1.0 * pos / total)
        neg = "{:.4f}".format(1.0 * neg / total)
        neu = "{:.4f}".format(1.0 * neu / total)

        dishesPopularity.append((pos, dish))

    dishesPopularity.sort(key=itemgetter(1))
    dishesPopularity.sort(key=itemgetter(0), reverse=True)

    return dishesPopularity


def main(root, restName, resultPath):
    tokenizer = TweetTokenizer()
    analyzer = SentimentIntensityAnalyzer()

    polaritiesTrue = []
    polaritiesPred = []

    for child in root:

        sentence = child.find('text').text
        opinions = child.find('opinions').findall('opinion')
        polarityTrue = []
        polarityPred = []

        for opinion in opinions:

            entity = opinion.get('target')
            entityStart = int(opinion.get('start'))
            entityEnd = int(opinion.get('end'))
            sentimentTrue = opinion.get('polarity')
            #context = contextor(tokenizer, sentence, entity, entityStart, entityEnd)
            #sentimentPred = vader(analyzer, context)
            sentimentPred = vader(analyzer, sentence)
            polarityTrue.append((entity, sentimentTrue))
            polarityPred.append((entity, sentimentPred))

        polaritiesTrue.append(polarityTrue)
        polaritiesPred.append(polarityPred)

    metrics(polaritiesTrue, polaritiesPred)

    topDishes = popularity(polaritiesPred)

    topDishesLog = resultPath + restName + "_topdishes.txt"
    topDishesPkl = resultPath + restName + "_topdishes.pkl"

    with open(topDishesLog, 'w') as f:
        for dish, pop in topDishes:
            f.write(dish + " " + pop + "\n")

    with open(topDishesPkl, 'wb') as f:
        pickle.dump(topDishes, f)


if __name__ == "__main__":

    restName = sys.argv[1]
    basePath = "../../data/annotated/sentiments/"
    resultPath = "results/"
    restaurant = basePath + restName + "_sentiments.xml"
    tree = ET.parse(restaurant)
    root = tree.getroot()

    main(root, restName, resultPath)