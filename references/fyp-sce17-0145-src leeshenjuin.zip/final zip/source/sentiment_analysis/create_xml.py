import sys
import pickle
from yattag import Doc, indent

restaurant = sys.argv[1]

resultPath = "results/"
sourcePath = "../../data/annotated/sentiments/"

picklefile = resultPath + restaurant + "_dishes.pkl"
sentfile = sourcePath + restaurant + "_sentences.txt"
xmlfile = sourcePath + restaurant + "_sentiments.xml"

doc, tag, text = Doc().tagtext()

with open(picklefile, 'rb') as f:    
    restaurant_dishes = pickle.load(f)

with open(sentfile, 'r') as f:    
    restaurant_sents = f.readlines()


count = 0

with tag('sentences'):
    for sent, dishes in zip(restaurant_sents, restaurant_dishes):
        count += 1
        if len(dishes) == 0:
            continue
        id = str(count)
        sent = sent.strip()
        with tag('sentence', id=id):
            with tag('text'):
                text(sent)
            with tag('opinions'):
                for dish in dishes:
                    start = sent.find(dish)
                    end = start + len(dish) - 1
                    start = str(start)
                    end = str(end)
                    with tag('opinion', target=dish, polarity='', start=start, end=end):
                        text('')

result = indent(
    doc.getvalue(),
    indentation = ' '*4,
    newline = '\r\n'
)

#print(result)

with open(xmlfile, 'w') as f:
    f.write(result)