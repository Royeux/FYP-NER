import sys
import pickle
import random


def float_equals(a, b, eps=0.00000001):
    if (abs(a - b) < eps):
        return True
    else:
        return False

def load_pickle(restaurant):
    with open(restaurant, 'rb') as f:
        topdishes = pickle.load(f)
    return topdishes


def save_pickle(top5, bottom5, restName, basePath):
    top5txt = basePath + restName + "_top5.txt"
    top5pkl = basePath + restName + "_top5.pkl"
    bottom5txt = basePath + restName + "_bottom5.txt"
    bottom5pkl = basePath + restName + "_bottom5.pkl"

    with open(top5txt, 'w') as f:
        for dish in top5:
            f.write(dish + "\n")

    with open(top5pkl, 'wb') as f:
        pickle.dump(top5, f)

    with open(bottom5txt, 'w') as f:
        for dish in bottom5:
            f.write(dish + "\n")

    with open(bottom5pkl, 'wb') as f:
        pickle.dump(bottom5, f)


def main(topdishes):
    candidates_top5 = []
    candidates_bottom5 = []
    top5 = []
    bottom5 = []

    for dish in topdishes:
        if float_equals(float(dish[0]), 1.0000):
            candidates_top5.append(dish[1])
        elif float_equals(float(dish[0]), 0.0000):
            candidates_bottom5.append(dish[1])

    candidates_top5_len = len(candidates_top5)
    #print candidates_top5_len
    candidates_bottom5_len = len(candidates_bottom5)
    #print candidates_bottom5_len
    top5_indices = set()
    bottom5_indices = set()

    for i in range(5):
        index1 = random.randint(0, candidates_top5_len - 1)
        while index1 in top5_indices:
            index1 = random.randint(0, candidates_top5_len - 1)
        top5_indices.add(index1)
        top5.append(candidates_top5[index1])

        index2 = random.randint(0, candidates_bottom5_len - 1)
        while index2 in bottom5_indices:
            index2 = random.randint(0, candidates_bottom5_len - 1)
        bottom5_indices.add(index2)
        bottom5.append(candidates_bottom5[index2])

    return top5, bottom5


if __name__ == "__main__":

    restName = sys.argv[1]
    basePath = "results/"
    restaurant = basePath + restName + "_topdishes.pkl"
    topdishes = load_pickle(restaurant)

    top5, bottom5 = main(topdishes)
    save_pickle(top5, bottom5, restName, basePath)