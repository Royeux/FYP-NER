from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
from flask.ext.heroku import Heroku

app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://localhost/dishes'
heroku = Heroku(app)
db = SQLAlchemy(app)

from models import Dish


# Set "homepage" to index.html
@app.route('/')
def index():
    restaurants = ["Tim Ho Wan (Plaza Singapura)", "Cherry Garden", "Red Star Restaurant", "Swee Choon Tim Sum Restaurant", "Victor's Kitchen (Sunshine Plaza)"]
    return render_template('index.html', restaurants=restaurants)

# Query database to retrieve dishes for selected restaurant and return results
@app.route('/dishes', methods=['GET', 'POST'])
def dishes():
    if request.form:
        restaurant = request.form['restaurant']
        gooddishes = Dish.query.filter(Dish.restaurant == restaurant).order_by(Dish.rank).limit(5).all()
        baddishes = Dish.query.filter(Dish.restaurant == restaurant).order_by(Dish.rank.desc()).limit(5).all()
        
    return render_template('success.html', restaurant=restaurant, gooddishes=gooddishes, baddishes=baddishes)

if __name__ == '__main__':
    app.debug = True
    app.run()