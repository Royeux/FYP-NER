from app import db

class Dish(db.Model):
    __tablename__ = "dishes"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    restaurant = db.Column(db.String, nullable=False)
    rank = db.Column(db.Integer, nullable=False)
 
    def __init__(self, name, restaurant, rank):
        self.name = name
        self.restaurant = restaurant
        self.rank = rank
 
    def __repr__(self):
        return '<Restaurant Name: {}\nDish Name: {}\nRank: {}>'.format(self.restaurant, self.name, self.rank)
